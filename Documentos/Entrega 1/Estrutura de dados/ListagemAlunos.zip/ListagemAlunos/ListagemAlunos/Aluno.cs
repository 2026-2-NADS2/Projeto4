﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Globalization;

namespace ListagemAlunos
{
    internal class Aluno
    {
        public string Nome { get; set; }
        public float Nota { get; set; }

        public Aluno(string nome, float nota)
        {
            Nome = nome;
            Nota = nota;
        }
    }
}
