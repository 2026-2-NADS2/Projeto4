﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Globalization;

namespace ListagemAlunos
{
    internal class Aluno
    {
        public string Nome { get; set; }
        public double Nota { get; set; }

        public Aluno(string nome, double nota)
        {
            Nome = nome;
            Nota = nota;
        }
    }
}
