﻿        using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Text;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace ListagemAlunos
{
    internal class AlunosDB
    {
        private readonly string _connectionString;

        public AlunosDB(string caminhoBanco)
        {
            _connectionString = $"Data Source={caminhoBanco}";
            CriarTabelaSeNaoExistir();
        }

        private void CriarTabelaSeNaoExistir()
        {
            using var conexao = new SqliteConnection(_connectionString);
            conexao.Open();

            using var comando = conexao.CreateCommand();
            comando.CommandText = @"
                CREATE TABLE IF NOT EXISTS Alunos (
                    Nome TEXT NOT NULL PRIMARY KEY,
                    Nota FLOAT NOT NULL
                );
            ";
            comando.ExecuteNonQuery();
        }

        public void Inserir(Aluno aluno)
        {
            if (aluno == null) throw new ArgumentNullException(nameof(aluno));

            using var conexao = new SqliteConnection(_connectionString);
            conexao.Open();

            using var comando = conexao.CreateCommand();
            comando.CommandText = @"
                INSERT INTO Alunos (Nome, Nota)
                VALUES (@nome, @nota);
            ";

            comando.Parameters.AddWithValue("@nome", aluno.Nome);
            comando.Parameters.AddWithValue("@nota", aluno.Nota);

            comando.ExecuteNonQuery();
        }

        public void Atualizar(Aluno aluno)
        {
            if (aluno == null) throw new ArgumentNullException(nameof(aluno));

            using var conexao = new SqliteConnection(_connectionString);
            conexao.Open();

            using var comando = conexao.CreateCommand();
            comando.CommandText = @"
                UPDATE Alunos
                   SET Nota  = @nota
                 WHERE Nome  = @nome;
            ";

            comando.Parameters.AddWithValue("@nome", aluno.Nome);
            comando.Parameters.AddWithValue("@nota", aluno.Nota);

            comando.ExecuteNonQuery();
        }

        public void Excluir(string nome)
        {
            using var conexao = new SqliteConnection(_connectionString);
            conexao.Open();

            using var comando = conexao.CreateCommand();
            comando.CommandText = @"
                DELETE FROM Alunos
                 WHERE Nome = @nome;
            ";

            comando.Parameters.AddWithValue("@nome", nome);
            comando.ExecuteNonQuery();
        }

        public Aluno? ObterPorNome(string nome)
        {
            using var conexao = new SqliteConnection(_connectionString);
            conexao.Open();

            using var comando = conexao.CreateCommand();
            comando.CommandText = @"
                SELECT Nome, Nota
                  FROM Alunos
                 WHERE Nome = @nome;
            ";
            comando.Parameters.AddWithValue("@nome", nome);

            using var reader = comando.ExecuteReader();

            if (reader.Read())
            {
                return new Aluno(reader.GetString(0), reader.GetFloat(1));
            }

            return null;
        }

        public List<Aluno> ObterTodos()
        {
            var lista = new List<Aluno>();

            using var conexao = new SqliteConnection(_connectionString);
            conexao.Open();

            using var comando = conexao.CreateCommand();
            comando.CommandText = @"
                SELECT Nome, Nota
                  FROM Alunos
              ORDER BY Nome;
            ";

            string Nome;
            float Nota;
            Aluno al;
            using var reader = comando.ExecuteReader();
            while (reader.Read())
            {
                Nome = reader.GetString(0);
                Nota = reader.GetFloat(1);
                al = new Aluno(Nome, Nota);
                lista.Add(al);
            }

            return lista;
        }

        public List<Aluno> ObterComDataIgualOuSuperior(string nome)
        {
            var lista = new List<Aluno>();

            using var conexao = new SqliteConnection(_connectionString);
            conexao.Open();

            using var comando = conexao.CreateCommand();
            comando.CommandText = @"
                SELECT Nome, Nota
                  FROM Aluno
                 WHERE Nome >= @nome
              ORDER BY Nome;
            ";
            comando.Parameters.AddWithValue("@nome", nome);

            string Nome;
            float Nota;
            Aluno al;
            using var reader = comando.ExecuteReader();
            while (reader.Read())
            {
                Nome = reader.GetString(0);
                Nota = reader.GetFloat(1);
                al = new Aluno(Nome, Nota);
                lista.Add(al);
            }

            return lista;
        }

        public void InserirOuAtualizar(Aluno aluno)
        {
            var existente = ObterPorNome(aluno.Nome);

            if (existente == null)
                Inserir(aluno);
            else
                Atualizar(aluno);
        }
    }
}
