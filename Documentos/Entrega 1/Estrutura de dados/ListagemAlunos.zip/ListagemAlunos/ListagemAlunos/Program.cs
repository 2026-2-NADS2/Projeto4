﻿using ListagemAlunos;
using System.Collections;
using System.Globalization;

Console.OutputEncoding = System.Text.Encoding.UTF8;

string caminhoBanco = @"..\..\..\alunos.db";
string caminhoCsv   = @"..\..\..\alunos.csv";
var repositorio     = new AlunosDB(caminhoBanco);

Console.WriteLine("-------Lista de Alunos e suas notas------");
Console.WriteLine($"Banco SQLite: {caminhoBanco}");
Console.WriteLine();

if (!File.Exists(caminhoCsv))
{
    Console.WriteLine("Arquivo CSV não encontrado.");
    return;
}

int quantidadeAlunos = ImportarCsv(caminhoCsv, repositorio);

Console.WriteLine();
Console.WriteLine($"Importação concluída. Registros processados: {quantidadeAlunos}");
Console.WriteLine();

List<Aluno> todos = repositorio.ObterTodos();

void ImprimirPagina(List<Aluno> lista, ref int inicio, ref int fim, int pageSize)
{
    Console.Clear();
    Console.WriteLine("-------Lista de Alunos e suas notas------");
    while (inicio < fim && inicio < todos.Count)
    {
        Console.WriteLine($"{inicio} - Nome: {todos[inicio].Nome} Nota: {todos[inicio].Nota}");
        inicio++;
    }
}

int pageSize = 10;
int inicio   = 0;
int fim      = inicio + pageSize;
int opcao    = 1;

while (opcao != 5)
{
    ImprimirPagina(todos, ref inicio, ref fim, pageSize);

    Console.WriteLine();
    Console.WriteLine("----- Opções -----");
    Console.WriteLine("1 - Próxima Página..");
    Console.WriteLine("2 - Página Anterior..");
    Console.WriteLine("3 - Primeira Página..");
    Console.WriteLine("4 - Última Página..");
    Console.WriteLine("5 - Sair da aplicação..");
    Console.WriteLine("Digite sua opção e aperte Enter.");

    string entrada = Console.ReadLine();

    if (!int.TryParse(entrada, out opcao))
    {
        Console.WriteLine("A opção escolhida deve ser um número.");
    }

    switch (opcao)
    {
        case 1:
            if (inicio < todos.Count)
            {
                fim = inicio + pageSize;
            }
            else
            {
                inicio = todos.Count - (todos.Count % pageSize == 0 ? pageSize : todos.Count % pageSize);
                fim = todos.Count;
            }
        break;

        case 2:
            inicio = inicio - 2 * pageSize;
            if (inicio < 0) inicio = 0;
            fim = inicio + pageSize;
        break;

        case 3:
            inicio = 0;
            fim = inicio + pageSize;
        break;

        case 4:
            inicio = todos.Count - pageSize;
            fim = inicio + pageSize;
        break;

        case 5:
            Environment.ExitCode = 5;
        break;
            
        default:
            inicio = inicio - pageSize;
            if (inicio < 0) inicio = 0;
            fim = inicio + pageSize;
        break;
    }
}

Console.WriteLine("Fim da Listagem!!");

Aluno convert(string[] alunos)
{
    if (alunos == null || alunos.Length == 0) return null;

    string nome = alunos.Length > 0 ? alunos[0].Trim() : string.Empty;

    double nota = 0;
    if (alunos.Length > 1)
    {
        var notaStr = alunos[1].Trim();
        if (!double.TryParse(notaStr, NumberStyles.Any, CultureInfo.InvariantCulture, out nota))
        {
            double.TryParse(notaStr, out nota);
        }
    }

    return new Aluno(nome, nota);
}

int ImportarCsv(string caminho, AlunosDB AppDB)
{
    int contador = 0;

    if (File.Exists(caminho))
    {
        using (StreamReader sr = new StreamReader(caminho))
        {
            string linha = sr.ReadLine();

            while ((linha = sr.ReadLine()) != null)
            {
                string[] alunoArr = linha.Split(';');

                var alunoObj = convert(alunoArr);
                if (alunoObj != null)
                {
                    AppDB.InserirOuAtualizar(alunoObj);
                    contador++;
                }
            }
        }

    }

    return contador;
}